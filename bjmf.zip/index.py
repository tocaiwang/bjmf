import json
import os
import re
import time
import urllib.request
import urllib.parse
import urllib.error
from http.cookiejar import CookieJar
import html

def load_config():
    try:
        config_str = os.environ.get('CONFIG_JSON', '')
        if config_str:
            return json.loads(config_str)
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(script_dir, 'data.json')
        
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"加载配置失败: {e}")
        return {}

def create_session(cookie_str):
    cookie_jar = CookieJar()
    cookie_list = cookie_str.split(';')
    for cookie in cookie_list:
        cookie = cookie.strip()
        if '=' in cookie:
            name, value = cookie.split('=', 1)
            cookie_jar.set_cookie(
                urllib.request.http.cookiejar.Cookie(
                    version=0,
                    name=name.strip(),
                    value=value.strip(),
                    port=None,
                    port_specified=False,
                    domain='.k8n.cn',
                    domain_specified=True,
                    domain_initial_dot=True,
                    path='/',
                    path_specified=True,
                    secure=False,
                    expires=None,
                    discard=False,
                    comment=None,
                    comment_url=None,
                    rest={}
                )
            )
    return cookie_jar

def make_request(url, cookie_str, method='GET', data=None, referer=None):
    try:
        cookie_jar = create_session(cookie_str)
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; X64; Linux; Android 9;) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Firefox/92.0  WeChat/x86_64 Weixin NetType/4G Language/zh_CN ABI/x86_64',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/wxpic,image/tpg,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Cookie': cookie_str
        }
        
        if referer:
            headers['Referer'] = referer
        
        if data:
            data = urllib.parse.urlencode(data).encode('utf-8')
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
        
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        response = opener.open(req, timeout=10)
        return response.read().decode('utf-8'), response.getcode()
    except Exception as e:
        print(f"请求失败: {e}")
        return None, None

def make_request_with_headers(url, headers, method='GET', data=None):
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        response = urllib.request.urlopen(req, timeout=10)
        return response.read().decode('utf-8'), response.getcode()
    except Exception as e:
        print(f"请求失败: {e}")
        return None, None

def get_user_and_class_info(student):
    user_info = {'name': '未找到'}
    class_info = {'class_id': '未找到', 'class_name': '未找到'}
    
    try:
        print(f"正在获取用户 {student['name']} 的信息...")
        
        Cookie_rs = re.search(r'remember_student_59ba36addc2b2f9401580f014c7f58ea4e30989d=[^;]+',
                             student['cookie'])
        if Cookie_rs:
            Cookie_rs = Cookie_rs.group(0)
            print(f"成功提取关键Cookie")
        else:
            Cookie_rs = student['cookie']
            print(f"使用完整Cookie")
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; X64; Linux; Android 9;) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Firefox/92.0  WeChat/x86_64 Weixin NetType/4G Language/zh_CN ABI/x86_64',
            'Cookie': Cookie_rs
        }
        
        # 获取用户个人信息
        url_my = "https://bjmf.k8n.cn/student/my"
        html_content, status_code = make_request_with_headers(url_my, headers)
        
        print(f"获取用户信息页面，状态码: {status_code}")
        
        if html_content and status_code == 200:
            print(f"响应内容长度: {len(html_content)} 字符")
            
            # 提取用户信息 - 从gconfig变量中提取
            gconfig_match = re.search(r'var gconfig=\{([^}]+)\}', html_content)
            if gconfig_match:
                gconfig_content = gconfig_match.group(1)
                print(f"成功找到gconfig变量")
                
                # 提取用户名
                uname_match = re.search(r"uname:'([^']+)'", gconfig_content)
                if uname_match:
                    user_info['name'] = uname_match.group(1)
                    print(f"成功获取用户名: {user_info['name']}")
                else:
                    print("未能在gconfig中找到用户名")
            else:
                print("未找到gconfig变量，尝试其他方法...")
                # 备用方法：查找HTML中的用户名
                name_match = re.search(r'<div[^>]*class="user-name"[^>]*>([^<]+)</div>', html_content)
                if name_match:
                    user_info['name'] = html.unescape(name_match.group(1).strip())
                    print(f"使用备用方法获取用户名: {user_info['name']}")
        else:
            print(f"获取用户信息页面失败")
        
        # 获取班级信息
        url_class = "https://bjmf.k8n.cn/student"
        html_content_class, status_code_class = make_request_with_headers(url_class, headers)
        
        print(f"获取班级信息页面，状态码: {status_code_class}")
        
        if html_content_class and status_code_class == 200:
            # 提取班级信息 - 从gconfig变量中提取
            gconfig_match = re.search(r'var gconfig=\{([^\}]+)\}', html_content_class)
            if gconfig_match:
                gconfig_content = gconfig_match.group(1)
                print(f"成功找到gconfig变量")
                
                # 提取班级相关信息
                cname_match = re.search(r"cname:'([^']+)'", gconfig_content)
                ctype_match = re.search(r"type:'([^']+)'", gconfig_content)
                class_id_match = re.search(r"id:'([^']+)'", gconfig_content)
                
                if cname_match:
                    class_info['cname'] = cname_match.group(1)
                    print(f"成功获取班级名称: {class_info['cname']}")
                if ctype_match:
                    class_info['ctype'] = ctype_match.group(1)
                if class_id_match:
                    class_info['class_id'] = class_id_match.group(1)
                    print(f"成功获取班级ID: {class_info['class_id']}")
            
            # 如果从gconfig没有获取到班级ID，尝试从页面其他地方获取
            if class_info.get('class_id') == "未找到":
                print("尝试从页面链接中获取班级ID...")
                
                # 方法1: 查找课程链接获取课程ID
                links = re.findall(r'<a[^>]*href="([^"]*)"[^>]*>([^<]*)</a>', html_content_class)
                print(f"找到 {len(links)} 个链接")
                
                for idx, (href, link_text) in enumerate(links):
                    course_match = re.search(r'/student/course/(\d+)', href)
                    if course_match:
                        class_info['class_id'] = course_match.group(1)
                        class_info['course_id'] = course_match.group(1)
                        class_info['class_name'] = html.unescape(link_text).strip()
                        print(f"从链接获取班级ID: {class_info['class_id']}, 班级名称: {class_info['class_name']}")
                        break
                
                # 方法2: 如果方法1失败，尝试直接查找所有数字ID
                if class_info.get('class_id') == "未找到":
                    print("尝试直接查找课程ID...")
                    course_ids = re.findall(r'/student/course/(\d+)', html_content_class)
                    if course_ids:
                        class_info['class_id'] = course_ids[0]
                        print(f"直接找到课程ID: {class_info['class_id']}")
                
                # 方法3: 查找所有可能的ID
                if class_info.get('class_id') == "未找到":
                    print("尝试查找所有可能的ID...")
                    # 查找JavaScript中的ID
                    js_ids = re.findall(r"id['\"]?\s*[:=]\s*['\"]?(\d+)['\"]?", html_content_class)
                    if js_ids:
                        # 过滤掉明显不是课程ID的数字（如时间戳）
                        valid_ids = [id for id in js_ids if len(id) >= 4 and len(id) <= 10]
                        if valid_ids:
                            class_info['class_id'] = valid_ids[0]
                            print(f"从JavaScript找到可能的ID: {class_info['class_id']}")
            
            # 查找班级码
            # 查找卡片中的班级码信息
            cards = re.findall(r'<div[^>]*class="card"[^>]*>(.*?)</div>', html_content_class, re.DOTALL)
            for card in cards:
                # 查找类似"班级码 XXXX"的模式
                class_code_match = re.search(r'班级码\s*([A-Z0-9]{4,10})', card)
                if class_code_match:
                    class_info['class_code'] = class_code_match.group(1)
                    print(f"成功获取班级码: {class_info['class_code']}")
                    break
            
            # 如果没找到，使用备选方法
            if 'class_code' not in class_info:
                print("尝试使用备选方法查找班级码...")
                page_text = html_content_class
                # 查找更精确的班级码模式
                class_code_matches = re.findall(r'\b[A-Z0-9]{4,8}\b', page_text)
                # 过滤掉明显不是班级码的内容
                filtered_codes = [code for code in class_code_matches 
                                if not (code.isdigit() and (len(code) > 6 or int(code) > 2030))]
                # 优先选择长度为5-6的字母数字组合
                preferred_codes = [code for code in filtered_codes 
                                 if len(code) >= 5 and len(code) <= 6 and not code.isdigit()]
                if preferred_codes:
                    class_info['class_code'] = preferred_codes[0]
                    print(f"使用备选方法获取班级码: {class_info['class_code']}")
                elif filtered_codes:
                    class_info['class_code'] = filtered_codes[0]
                    print(f"使用备选方法获取班级码: {class_info['class_code']}")
                else:
                    class_info['class_code'] = "未找到"
        else:
            print(f"获取班级信息页面失败")
                
    except Exception as e:
        print(f"获取用户信息失败: {e}")
        import traceback
        traceback.print_exc()
    
    print(f"最终结果 - 用户名: {user_info.get('name', '未找到')}, 班级ID: {class_info.get('class_id', '未找到')}")
    return user_info, class_info

def sendQQmessage(msg, qqkey):
    try:
        url = f"https://qmsg.zendee.cn/send/{qqkey}"
        data = urllib.parse.urlencode({"msg": msg}).encode('utf-8')
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        urllib.request.urlopen(req, timeout=3)
    except Exception as e:
        print(f"发送QQ消息失败: {e}")

def wx_send(msg, wxkey):
    try:
        url = f"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key={wxkey}"
        data = json.dumps({
            "msgtype": "text",
            "text": {
                "content": msg
            }
        }).encode('utf-8')
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Content-Type', 'application/json')
        urllib.request.urlopen(req, timeout=3)
    except Exception as e:
        print(f"发送微信消息失败: {e}")

def Task(student):
    try:
        user_info, class_info = get_user_and_class_info(student)
        
        user_name = user_info.get('name', '未找到')
        if user_name == "未找到":
            print(f"无法获取用户信息，可能是cookie过期或无效，跳过用户 {student['name']} 的签到任务")
            return student.get('name', '未知'), 'skip'
            
        ClassID = class_info.get('class_id', student['class'])
        if not ClassID or ClassID == "未找到" or not ClassID:
            ClassID = student['class']
            print(f"使用配置文件中的班级ID: {ClassID}")
        else:
            print(f"使用从网页获取的班级ID: {ClassID}")
            
        name = user_info.get('name', student['name'])
        if not name or name == "未找到":
            name = student['name']
            
        class_name = class_info.get('class_name', '未找到')
        if class_name == "未找到" and not ClassID:
            print(f"无法获取班级信息，跳过用户 {name} 的签到任务")
            return name, 'skip'
            
        lat = student['lat']
        lng = student['lng']
        ACC = student['acc']
        
        print(f"开始签到 - 用户: {name}, 班级ID: {ClassID}, 经纬度: ({lat}, {lng})")
        
        warmup_url = "https://bjmf.k8n.cn/student/my"
        try:
            make_request(warmup_url, student['cookie'])
        except Exception as e:
            print(f"会话预热失败: {e}")

        url = f'https://bjmf.k8n.cn/student/course/{ClassID}/punchs'
        referer = f'https://bjmf.k8n.cn/student/course/{ClassID}'
        
        print(f"请求签到列表URL: {url}")
        response_text, status_code = make_request(url, student['cookie'], referer=referer)

        if not response_text:
            print("请求签到列表失败")
            return name, 'error'

        print(f"签到列表响应状态码: {status_code}, 内容长度: {len(response_text)}")
        
        matches = []
        
        pattern_id = re.compile(r'punchcard_(\d+)')
        matches_id = pattern_id.findall(response_text)
        matches.extend(matches_id)
        
        pattern_link = re.compile(r'/student/punchs/course/\d+/([0-9]+)')
        matches_link = pattern_link.findall(response_text)
        matches.extend(matches_link)
        
        matches = list(set(matches))

        print(f"找到 {len(matches)} 个签到项: {matches}")

        if not matches:
            if '已签到' in response_text or 'punch-success-info' in response_text or 'punch-status' in response_text:
                print("检测到已完成签到")
                return name, 'already_signed'

            print("未找到在进行的签到/不在签到时间内")
            print(f"Debug: Status Code: {status_code}")
            print(f"响应内容预览: {response_text[:500]}")
            
            return name, 'no_sign_in'

        for match in matches:
            print(f"签到项: {match}")
            url1 = f"https://bjmf.k8n.cn/student/punchs/course/{ClassID}/{match}"
            payload = {
                'id': match,
                'lat': lat,
                'lng': lng,
                'acc': ACC,
                'res': '',
                'gps_addr': ''
            }

            response_text, status_code = make_request(url1, student['cookie'], method='POST', data=payload)

            if response_text and status_code == 200:
                print("网络请求成功")
                
                title_match = re.search(r'<div[^>]*id="title"[^>]*>([^<]+)</div>', response_text)
                if title_match:
                    title_text = html.unescape(title_match.group(1).strip())
                    if "已签到" in title_text:
                        print("已签到！无需再次签到")
                        return name, 'already_signed'
                    elif "未开始" in title_text:
                        print("未开始签到,请稍后")
                        return name, 'not_started'
                    else:
                        print("本次签到成功")
                        return name, 'success'
                else:
                    print("签到请求成功，但无法确定状态")
                    return name, 'success'
            else:
                print(f"请求失败，状态码: {status_code}")
                return name, 'error'
        
        return name, 'no_sign_in'
    except Exception as e:
        print(f"发生错误{e}，跳过该配置......")
        import traceback
        traceback.print_exc()
        return student.get('name', '未知'), 'error'

def main():
    try:
        config = load_config()
        students = config.get('students', [])
        
        attendance_results = []
        
        for i, student in enumerate(students):
            if not student.get('class') or student['class'].strip() == "":
                try:
                    user_info, class_info = get_user_and_class_info(student)
                    user_name = user_info.get('name', '未找到')
                    if user_name == "未找到":
                        attendance_results.append((student['name'], 'skip'))
                        continue
                    
                    class_id = class_info.get('class_id')
                    if class_id and class_id != "未找到":
                        student['class'] = class_id
                        config['students'][i]['class'] = class_id
                except:
                    continue
            
            try:
                result = Task(student)
                if result:
                    attendance_results.append(result)

                    try:
                        qmsg_key = student.get('QmsgKEY', '')
                        if qmsg_key:
                            status = result[1]
                            name = student['name']

                            if status == "success":
                                msg = f"✅【签到成功】{name} 签到完成！"
                            elif status == "already_signed":
                                msg = f"⚠️【已签到】{name} 今天已经签过啦！"
                            else:
                                msg = f"❌【签到失败】{name} 请检查Cookie或网络！"

                            sendQQmessage(msg, qmsg_key)
                    except:
                        pass

            except Exception as e:
                print(f"执行签到任务时出错: {e}")

        print(f"签到任务完成，共处理 {len(attendance_results)} 个用户")
        
    except KeyboardInterrupt:
        pass
    finally:
        time.sleep(1)

def main_handler(event, context):
    try:
        print("开始执行签到任务...")
        main()
        print("签到任务执行完成")
        return {
            "code": 0,
            "message": "签到任务执行完成"
        }
    except Exception as e:
        print(f"执行失败: {str(e)}")
        return {
            "code": -1,
            "message": f"执行失败: {str(e)}"
        }

if __name__ == "__main__":
    result = main_handler({}, {})
    print(json.dumps(result, ensure_ascii=False))
